let accounts = [];

// Function to create a new account
function createAccount(username, pin, balance) {
  let account = {
    username: username,
    pin: pin,
    balance: balance,
    attempts: 3
  };
  accounts.push(account);
  updateAccountList();
}

// Function to update the account list
function updateAccountList() {
  let accountListUl = document.getElementById("account-list-ul");
  accountListUl.innerHTML = "";
  accounts.forEach((account) => {
    let li = document.createElement("li");
    li.textContent = `Username: ${account.username}, Balance: ${account.balance}`;
    accountListUl.appendChild(li);
  });
}

// Function to transfer money
function transferMoney(fromUsername, toUsername, amount, pin) {
  let fromAccount = accounts.find((account) => account.username === fromUsername);
  let toAccount = accounts.find((account) => account.username === toUsername);
  if (fromAccount && toAccount) {
    if (fromAccount.pin === pin) {
      if (fromAccount.balance >= amount) {
        fromAccount.balance -= amount;
        toAccount.balance += amount;
        updateAccountList();
        alert("Transaction successful!");
      } else {
        alert("Insufficient balance!");
      }
    } else {
      fromAccount.attempts--;
      if (fromAccount.attempts > 3) {
        alert("Account locked due to incorrect PIN!");
      } else {
        alert("Incorrect PIN! You have " + fromAccount.attempts + " attempts left.");
      }
    }
  } else {
    alert("Account not found!");
  }
}

// Event listeners
document.getElementById("signup-btn").addEventListener("click", (e) => {
  e.preventDefault();
  let username = document.getElementById("username").value;
  let pin = document.getElementById("pin").value;
  let balance = parseInt(document.getElementById("balance").value);
  createAccount(username, pin, balance);
});

document.getElementById("transfer-btn").addEventListener("click", (e) => {
  e.preventDefault();
  let fromUsername = document.getElementById("from-username").value;
  let toUsername = document.getElementById("to-username").value;
  let amount = parseInt(document.getElementById("amount").value);
  let transferPin = document.getElementById("transfer-pin").value;
  transferMoney(fromUsername, toUsername, amount, transferPin);
});